const { MongoClient } = require('mongodb');
const bcrypt = require('bcrypt');

const uri = "mongodb+srv://rasaadmin:YVXmCORcc639kG0o@rasabot.hfg7kbb.mongodb.net/?retryWrites=true&w=majority&appName=rasabot";

(async () => {
    const client = new MongoClient(uri);

    try {
        await client.connect();
        console.log("Connected successfully to MongoDB");
        
        const db = client.db("rasabot");
        const collection = db.collection("users");

        const user = {
            name: "Hassan",
            email: "hassan_12@gmail.com",
            password: "popcorn123",
            dob: new Date("2004-01-01"),
            gender: "male",
            bloodGroup: "b+"
        };

        const saltRounds = 10;
        const hashedPassword = await bcrypt.hash(user.password, saltRounds);
        user.password = hashedPassword;
        
        const result = await collection.insertOne(user);
        if (result && result.result && result.result.ok === 1 && result.ops && result.ops.length > 0) {
            console.log("Document inserted:", result.ops[0]);
        } else {
            console.error("Failed to insert document:", result && result.errmsg ? result.errmsg : "Unknown error");
        }
        
        
    } catch (error) {
        console.error("An error occurred:", error);
    } finally {
        await client.close();
        console.log("MongoDB connection closed");
        console.log("Script completed successfully.");
    }
})();
