const express = require('express');
const mongoose = require('mongoose');
const bcrypt = require('bcrypt');
const path = require('path');
const auth = require('./routes/auth');
const User = require('./models/user'); // Import the User model

const app = express();

// Set EJS as the view engine
app.set('view engine', 'ejs');

// Define the directory for static files
app.use(express.static(path.join(__dirname, 'public')));

// Body parser middleware
app.use(express.json());

// Connect to MongoDB
mongoose.connect("mongodb+srv://rasaadmin:YVXmCORcc639kG0o@rasabot.hfg7kbb.mongodb.net/?retryWrites=true&w=majority&appName=rasabot", {
    useNewUrlParser: true,
    useUnifiedTopology: true
})
.then(() => console.log('MongoDB Atlas connection successful'))
.catch(err => console.error('MongoDB Atlas connection error:', err));

// Define routes for user signup
app.use('/api/users', require('./routes/userRoutes'));

// Protected route example
app.get('/api/protected', auth, (req, res) => {
    res.send('Protected route accessed');
});

// Define a route handler for the root URL
app.get('/', (req, res) => {
    res.render('home');
});

// Updated route for index page
app.get('/index', (req, res) => {
    res.render('index');
});

// Route handler for user authentication (sign-in)
app.post('/api/signin', async (req, res) => {
    try {
        const { email, password } = req.body;

        // Query the database for the user with the provided email
        const user = await User.findOne({ email: email });

        // Check if the user exists and if the provided password matches the hashed password in the database
        if (user && await bcrypt.compare(password, user.password)) {
            // Authentication successful
            // Redirect to embedded rasabot HTML file
            res.sendFile(path.join(__dirname, '../views/index.html'));
        } else {
            // Authentication failed
            res.status(401).json({ success: false, message: 'Authentication failed' });
        }
    } catch (error) {
        console.error('Error signing in:', error);
        res.status(500).json({ success: false, message: 'Internal server error' });
    }
});

const PORT = process.env.PORT || 3000;

app.listen(PORT, () => console.log(`Server started on port ${PORT}`));
