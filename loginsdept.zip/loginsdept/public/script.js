// Function to calculate password strength
function calculatePasswordStrength(password) {
    if (password.length < 8) {
        return "Weak";
    } else if (password.length < 12) {
        return "Medium";
    } else {
        return "Strong";
    }
}

// Function to update password strength meter
function updatePasswordStrengthMeter(password) {
    const strengthIndicator = document.getElementById("password-strength");
    const strength = calculatePasswordStrength(password);
    
    strengthIndicator.textContent = strength;
    if (strength === "Weak") {
        strengthIndicator.style.color = "red";
    } else if (strength === "Medium") {
        strengthIndicator.style.color = "orange";
    } else {
        strengthIndicator.style.color = "green";
    }
}

// Function to validate the signup form
function validateSignupForm() {
    var name = document.getElementById("name").value;
    var email = document.getElementById("signup-email").value;
    var password = document.getElementById("signup-password").value;
    var dob = document.getElementById("dob").value;
    var gender = document.getElementById("gender").value;
    var bloodGroup = document.getElementById("blood-group").value;

    if (name === "" || email === "" || password === "" || dob === "" || gender === "" || bloodGroup === "") {
        document.getElementById("signup-error-message").textContent = "Please fill out all fields.";
        document.getElementById("signup-error-message").style.display = "block";
        return false;
    }

    if (password.length < 8) {
        document.getElementById("signup-error-message").textContent = "Password must be at least 8 characters long.";
        document.getElementById("signup-error-message").style.display = "block";
        return false;
    }

    return true;
}

// Event listener for signup form submission
document.getElementById("signup-form").addEventListener("submit", function (event) {
    event.preventDefault();

    if (!validateSignupForm()) {
        return;
    }

    const formData = new FormData(this);
    fetch("/api/users", {
        method: "POST",
        body: formData
    })    
    .then(response => {
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        return response.json();
    })
    .then(data => {
        alert("User created successfully");
        console.log("User created successfully:", data);
    })
    .catch(error => {
        alert("Error creating user: " + error.message);
        console.error("Error creating user:", error);
    });
});

// Event listener for password input to update the password strength meter
document.getElementById("signup-password").addEventListener("input", function() {
    const password = this.value;
    updatePasswordStrengthMeter(password);
});

// Function to validate the sign-in form
function validateSigninForm() {
    var email = document.getElementById("signin-email").value;
    var password = document.getElementById("signin-password").value;

    if (email === "" || password === "") {
        alert("Please fill out all fields.");
        return false;
    }

    return true;
}

// Event listener for sign-in form submission
document.getElementById("signin-form").addEventListener("submit", function (event) {
    event.preventDefault();

    if (!validateSigninForm()) {
        return;
    }

    const email = document.getElementById("signin-email").value;
    const password = document.getElementById("signin-password").value;

    fetch("/api/signin", {
        method: "POST",
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ email, password })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            alert("Sign-in successful");
        } else {
            alert(data.message); // This should be "User not found" or "Wrong username or password" based on your server response
        }
    })
    .catch(error => {
        console.error("Error signing in:", error);
        alert("Error signing in: " + error.message);
    });
});

// Function to handle registration form visibility
const container = document.getElementById('container');
const registerBtn = document.getElementById('register');
const loginBtn = document.getElementById('login');

registerBtn.addEventListener('click', () => {
    container.classList.add("active");
});

loginBtn.addEventListener('click', () => {
    container.classList.remove("active");
});
